rootProject.name = "SmartLedger"
include(":app")


