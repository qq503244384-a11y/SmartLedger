package com.example.smartledger.ui.theme

import androidx.compose.material3.Typography

val Typography = Typography()


